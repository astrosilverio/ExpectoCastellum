helpstatement = '''The interpreter assumes your input will be mostly in the form
command (opt)[argument]. Allowable commands include go (or move) [direction], look,
where, examine (or x), take (or get) [thing], drop (or put) [thing], eat [thing],
cast [spell], inventory (or invent), help, sort, fly (or ride) (opt)broom, quit. Save and load
not working. [direction] maps to go [direction], and [spell] maps to cast [spell].

Type info to learn about yourself.'''

