def no_start_location():
	print '''You have not yet set the room where you want the player to start. Use <gamename>.start_location = 'NameOfStartingRoom' to set the start_location.'''
	
